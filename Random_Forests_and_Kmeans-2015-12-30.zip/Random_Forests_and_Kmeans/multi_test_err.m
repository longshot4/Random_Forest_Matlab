tic;
%data=csvread('multiclass-training-points.csv');
%results=csvread('multiclass-training-labels.csv');
err=[];
treenums=[];
for i=1:100
err(i)=multirandomforesttest(data,results,trees,i);
treenums(i)=i;
end
headers={'Trees','Error'};
dataout=[treenums',1-err'];
csvwrite_with_headers('SDSP_Tree_Error.txt',dataout,headers);
donetime=toc