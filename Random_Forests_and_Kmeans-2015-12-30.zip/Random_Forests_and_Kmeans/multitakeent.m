function entropyres=multitakeent(results)
    a=length(results);
    eachamount=zeros(1,12); %holds amount of each class
    for j=1:a
       eachamount(results(j))=eachamount(results(j))+1;
    end
    eachfract=eachamount/a;
    featent=0;
    for k=1:12
        if  eachfract(k)==0
            continue 
        end
        featent=featent - eachfract(k)*log2(eachfract(k));
    end
    entropyres=featent;