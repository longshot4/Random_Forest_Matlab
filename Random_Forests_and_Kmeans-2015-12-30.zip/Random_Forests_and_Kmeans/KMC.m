function [truelabels, kmclabels, answerclass, iter] = KMC(datain, k, sep)

%%% Seperate Labels and data
markers=datain(:,1);
realclasses=unique(markers);
for k=1:length(realclasses)
    markers(markers==realclasses(k))=k;
    %{
    if k<=3
        markers(markers==realclasses(k))=1;
    elseif k<=6
        markers(markers==realclasses(k))=1;
    elseif k<=9
        markers(markers==realclasses(k))=2;
    else
        markers(markers==realclasses(k))=2;
    end
    %}
end
results=markers;
data=datain(:,2:end);




%% Seperate Training and Testing
testdata=[];
testresults=[];
testnum=80; %%% number of test points from each class
for k=1:length(realclasses)
    testpoints{k}=randperm(400,testnum)+400*(k-1); %%% based on num in each class
    %%put in test set
    testdata(1+testnum*(k-1):testnum+testnum*(k-1),:)=data(testpoints{k},:);
    testresults(1+testnum*(k-1):testnum+testnum*(k-1),:)=results(testpoints{k});
    
end
%%delete from training set
    data(cell2mat(testpoints),:)=[];
    results(cell2mat(testpoints))=[];
clear testpoints;









k=length(unique(markers));
%%% Initial means
[rows,cols]=size(data);
for j=1:k
spots(j)=ceil((sep-testnum*12/k)*j-rand(1)*(sep-testnum*12/k-1));
end
means=data(spots,:);
old=zeros(k,cols);





%%% main loop
iter=0;
while sum(abs(means-old))>10^-6
clusters=cell(k,1);
answerclass=cell(k,1);
    for q=1:rows
        for r=1:k
            comp=[data(q,:);means(r,:)];
            d(r) = pdist(comp,'euclidean');
        end
        [~,class]=min(d);
        clusters{class}=[clusters{class};data(q,:)];
        answerclass{class}=[answerclass{class};results(q)];
    end
    
    old=means;
    
    for j=1:k
    means(k,:)=mean(clusters{k}); 
    end
iter=iter+1;
end



%%%%%%%%%%%%%%%%% Check answers by generating confusion matrix


[rows,cols]=size(testdata);
clusters=cell(k,1);
answerclass=cell(k,1);
 for q=1:rows
        for r=1:k
            comp=[testdata(q,:);means(r,:)];
            d(r) = pdist(comp,'euclidean');
        end
        [~,class]=min(d);
        clusters{class}=[clusters{class};testdata(q,:)];
        answerclass{class}=[answerclass{class};testresults(q)];
 end
    
 
truelabels=[];
kmclabels=[];
for y=1:k
    truelabels=[truelabels, answerclass{y}'];
    %g=mode(answerclass{y});
    kmclabels=[kmclabels, ones(1,length(answerclass{y}))*y];
end





