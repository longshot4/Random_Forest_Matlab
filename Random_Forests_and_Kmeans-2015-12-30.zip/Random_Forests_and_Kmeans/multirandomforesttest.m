function [err,class]=multirandomforesttest(data,results,trees,nums)
%error of tree
[points,~]=size(data);
class=[];
for x=1:points
    pathpredictedclass=[];
    for a=1:nums
        split=1;
        for b=1:length(trees{a})
            [len,~]=size(trees{a}{b});
            for k=1:len
                if k==len
                    %%%%% Only differnet part from the binary case
                    for number=1:12
                        totinnode(number)=sum(trees{a}{b}{k,5}==(number));
                    end
                    [~,pos]=max(totinnode);
                    %%%%%
                else
                    att=trees{a}{b}{k,2};
                    val=trees{a}{b}{k,3};
                    if data(x,att)>=val
                        split=1;
                    else
                        split=0;
                    end
                    if trees{a}{b}{k+1,4} ~= split
                        break
                    end
                end    
            end
        end
        pathpredictedclass(a)=pos;
    end
    class(x)=mode(pathpredictedclass);
end

err=sum(class'==results)/length(results);