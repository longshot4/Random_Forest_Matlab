function [confusionmat,Pr,Re,F,Err]=makeconfusion2(classpredicted, classactual)
%%%confusionmatrix

n=length(classpredicted);
%%Confusion Matrix setup
unis=unique(classactual);
cls=length(unis);
confusionmat=zeros(cls);
for i=1:n
    if classpredicted(i)==classactual(i)
        confusionmat(classpredicted(i),classpredicted(i))=confusionmat(classpredicted(i),classpredicted(i))+1;
    else
       confusionmat(classactual(i),classpredicted(i))=confusionmat(classactual(i),classpredicted(i))+1;
    end
end

Pr=[];
Re=[];
F=[];
Err=trace(confusionmat)/(sum(sum(confusionmat)));
for f=1:cls
    Pr(f)=confusionmat(f,f)/sum(confusionmat(:,f));
    Re(f)=confusionmat(f,f)/sum(confusionmat(f,:));
    F(f)=(2*Re(f)*Pr(f))/(Re(f)+Pr(f));
end

