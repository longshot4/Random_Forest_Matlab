%%%Plot Data Classes

%%%% Complete Demo Run
clc
clear

%% Load Data
tic;
load('Activity.mat');  %% Data is in the DataMat variable

data=DataMat(:,2:end);      %% Varaibles

markers=DataMat(:,1);
realclasses=unique(markers); %% Key between actual label and testing label
clust=cell(length(realclasses),1);
for k=1:length(realclasses)
    markers(markers==realclasses(k))=k;
    %{
    if k<=3
        markers(markers==realclasses(k))=1;
    elseif k<=6
        markers(markers==realclasses(k))=2;
    elseif k<=9
        markers(markers==realclasses(k))=3;
    else
        markers(markers==realclasses(k))=4;
    end
    %}
end
results=markers;            %% Class labels
realclasses=unique(results);

%% Seperate Clusters
[a,b,c]=svd(data);

twospace=a(:,1:2)*b(1:2,1:2)*c(:,1:2)';

for w=1:length(realclasses)
    if w==1
        figure(1);scatter(twospace(1+400*(w-1):400*w,1),twospace(1+400*(w-1):400*w,2),'g','MarkerFaceColor','g'); hold on;
    elseif w==2
        figure(1);scatter(twospace(1+400*(w-1):400*w,1),twospace(1+400*(w-1):400*w,2),'r','MarkerFaceColor','r'); hold on;
    elseif w==3
        figure(1);scatter(twospace(1+400*(w-1):400*w,1),twospace(1+400*(w-1):400*w,2),'b','MarkerFaceColor','b'); hold on;
    elseif w==4
        figure(1);scatter(twospace(1+400*(w-1):400*w,1),twospace(1+400*(w-1):400*w,2),'y','MarkerFaceColor','y'); hold on;
        elseif w==5
        figure(1);scatter(twospace(1+400*(w-1):400*w,1),twospace(1+400*(w-1):400*w,2),'c','MarkerFaceColor','c'); hold on;
        elseif w==6
        figure(1);scatter(twospace(1+400*(w-1):400*w,1),twospace(1+400*(w-1):400*w,2),'m','MarkerFaceColor','m'); hold on;
        elseif w==7
        figure(1);scatter(twospace(1+400*(w-1):400*w,1),twospace(1+400*(w-1):400*w,2),[4,7,1],'MarkerFaceColor',[4,7,1]); hold on;
        elseif w==8
        figure(1);scatter(twospace(1+400*(w-1):400*w,1),twospace(1+400*(w-1):400*w,2),'k','MarkerFaceColor','k'); hold on;
        elseif w==9
        figure(1);scatter(twospace(1+400*(w-1):400*w,1),twospace(1+400*(w-1):400*w,2),'k','MarkerFaceColor','k'); hold on;
        elseif w==10
        figure(1);scatter(twospace(1+400*(w-1):400*w,1),twospace(1+400*(w-1):400*w,2),'k','MarkerFaceColor','k'); hold on;
        elseif w==11
        figure(1);scatter(twospace(1+400*(w-1):400*w,1),twospace(1+400*(w-1):400*w,2),'k','MarkerFaceColor','k'); hold on;
        elseif w==12
        figure(1);scatter(twospace(1+400*(w-1):400*w,1),twospace(1+400*(w-1):400*w,2),'k','MarkerFaceColor','k'); hold on;
    end
end
figure(1);title('2-D Representation of the Data using SVD');legend('2000s','90s','80s','70s');hold off;