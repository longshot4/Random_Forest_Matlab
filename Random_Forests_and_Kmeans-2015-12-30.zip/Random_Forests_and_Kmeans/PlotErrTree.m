

load('DVA_Tree_All.mat')
figure(2);plot((1-err)*100,'g','LineWidth',1.5);title('Random Forest: Activity Classisfication Error');xlabel('Number of Trees');ylabel('Error(%)');
axis([0 100 0 50]);set(gca,...
          'linewidth',3,...
          'fontsize',10,...
          'fontname','arial');


