function err=randomforesttest(data,results,trees,nums)
%error of tree
[points,~]=size(data);
class=[];
for x=1:points
    
    total=0;
    for a=1:nums
        split=1;
        call=0;
        for b=1:length(trees{a})
            [len,~]=size(trees{a}{b});
            for k=1:len
                if k==len
                    if sum(trees{a}{b}{k,5})>=0
                        call=1;
                    else
                        call=-1;
                    end
                else
                    att=trees{a}{b}{k,2};
                    val=trees{a}{b}{k,3};
                    if data(x,att)>=val
                        split=1;
                    else
                        split=0;
                    end
                    if trees{a}{b}{k+1,4} ~= split
                        break
                    end
                end
                
            end
            if call~=0
                break
            end
        end
        total=total+call;
        
    end
    class(x)=total;
end
class=(class>=0)-(class<0);
err=sum(class'==results)/length(results);
