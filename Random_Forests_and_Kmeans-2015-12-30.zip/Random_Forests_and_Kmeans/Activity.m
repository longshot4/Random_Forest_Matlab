%%Song Database analysis
clc
clear
newdata=dlmread('DVA_ssdata.csv',',');

for j=1:12
    newdata(1+(j-1)*400:j*400,1)=j;
end

DataMat=newdata;
save('Activity.mat','DataMat','-v7.3');