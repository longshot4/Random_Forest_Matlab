clc
clear

tic;
for times=1:5
    
load('Activity.mat');
datain=DataMat;
k=12;
[c,~]=size(DataMat);
sep=c/k;

[truelabels, kmclabels,a, iter] = KMC(datain, k, sep);


[confusionmat{times},Pr{times},Re{times},F{times},Err{times}]=makeconfusion2(kmclabels, truelabels);

end

outagain=toc