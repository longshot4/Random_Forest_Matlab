function ROCpts=genroc(confusionmat)
ROCpts=zeros(12,2);
for i=1:12
    for j=1:2
        if j==1
            ROCpts(i,j)=(sum(confusionmat(:,i))-confusionmat(i,i))/(sum(sum(confusionmat))-sum(confusionmat(i,:)));%false alarm 
        else
            ROCpts(i,j)=confusionmat(i,i)/sum(confusionmat(i,:)); %true positive
        end
    end
end
figure(1); plot(0:.1:1,0:.1:1,'k--','LineWidth',1.5);title('Random Forest ROC Graph');ylabel('True Positive Rate');xlabel('False Positive Rate');hold on
plot(ROCpts(:,1),ROCpts(:,2),'bo','MarkerSize', 10,'MarkerFaceColor','b');set(gca,...
          'linewidth',3,...
          'fontsize',10,...
          'fontname','arial');hold off


for w=1:12
    lab=['  ', num2str(w)];
    text(ROCpts(w,1),ROCpts(w,2),lab,'FontSize',18 );
end
