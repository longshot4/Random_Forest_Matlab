clc
clear
load('MusicByYear.mat');
[m,c]=size(DataMat(:,2:end));
data=DataMat(:,2:end);


markers=DataMat(:,1);
realclasses=unique(markers);
for k=1:length(realclasses)
    markers(markers==realclasses(k))=k;
end
results=markers;

tic;
trees=cell(0,0);
for j=1:100
    %%%%% data for individual trees
         n=800;
         bootindex=ceil(rand(n,1)*m);
         for i=1:n;
             dataB(i,:)=data(bootindex(i),:);
             resultsB(i)=results(bootindex(i));
         end


         nf=30;
         featureindex=ceil(rand(nf,1)*c);
         for i=1:nf;
             dataBF(:,i)=dataB(:,featureindex(i));
         end



    %%%%%%%%%
    node=cell(1,5);
    node{1,1}=dataBF;
    node{1,5}=resultsB;
    node{1,4}=1;

    path=cell(1,1);
    path{1}=node;


    tic;
    treeEnd=0;
    while treeEnd==0
    iter=1;
    newpath=cell(0,0);
    h=length(path);
    notnew=0;
        for pathnum=1:h
            node=path{pathnum};
            nodenum=length(path{pathnum}(:,1));
            currentnodedata=path{pathnum}{nodenum,1};
            currentlabels=path{pathnum}{nodenum,5};
            
            %%%Done splitting??
            for q=1:10
            testa=sum(currentlabels==q)/length(currentlabels);
                if testa>.9
                    break
                end
            end
            
            if nodenum==nf || length(currentnodedata(:,1))<=20 || testa>.9 
                newpath{iter}=node;
                iter=iter+1;
                notnew=notnew+1;
                if notnew==h
                    treeEnd=1;
                    break
                end
                continue
            end
            
                [bestfeat,bestval,nodeL,Llabels,nodeR,Rlabels]=multiattAsplit(currentnodedata,currentlabels,featureindex);
                
                %%%% Save teh split and feature
                node{nodenum,2}=bestfeat;
                node{nodenum,3}=bestval;


                %%%%%%Create 2 new paths

                node(nodenum+1,:)=cell(1,5);
                node{nodenum+1,1}=nodeL;
                node{nodenum+1,4}=1;
                node{nodenum+1,5}=Llabels;
                newpath{iter}=node;
                iter=iter+1;
                
                node(nodenum+1,:)=cell(1,5);
                node{nodenum+1,1}=nodeR;
                node{nodenum+1,4}=0;
                node{nodenum+1,5}=Rlabels;
                newpath{iter}=node;
                iter=iter+1;
        end
    path=newpath;
    end    
    trees{j}=path;
end
outtime=toc 
