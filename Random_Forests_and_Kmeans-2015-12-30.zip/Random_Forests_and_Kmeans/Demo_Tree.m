%%%% Complete Demo Run
clc
clear

%% Load Data
tic;
load('Activity.mat');  %% Data is in the DataMat variable

data=DataMat(:,2:end);      %% Varaibles

markers=DataMat(:,1);
realclasses=unique(markers); %% Key between actual label and testing label
for k=1:length(realclasses)
    markers(markers==realclasses(k))=k;
    %{
    if k<=3
        markers(markers==realclasses(k))=1;
    elseif k<=6
        markers(markers==realclasses(k))=1;
    elseif k<=9
        markers(markers==realclasses(k))=2;
    else
        markers(markers==realclasses(k))=2;
    end
    %}
end
results=markers;            %% Class labels
realclasses=unique(results);


%% Seperate Training and Testing
testdata=[];
testresults=[];
testnum=80; %%% number of test points from each class
for k=1:length(realclasses)
    testpoints{k}=randperm(400,testnum)+400*(k-1); %%% based on num in each class
    %%put in test set
    testdata(1+testnum*(k-1):testnum+testnum*(k-1),:)=data(testpoints{k},:);
    testresults(1+testnum*(k-1):testnum+testnum*(k-1),:)=results(testpoints{k});
    
end
%%delete from training set
    data(cell2mat(testpoints),:)=[];
    results(cell2mat(testpoints))=[];
clear testpoints;

[m,c]=size(data);
%% Run Tree

trees=cell(0,0);
for j=1:100
    %%%%% data for individual trees
         n=800;
         bootindex=ceil(rand(n,1)*m);
         for i=1:n;
             dataB(i,:)=data(bootindex(i),:);
             resultsB(i)=results(bootindex(i));
         end


         nf=30;
         featureindex=ceil(rand(nf,1)*c);
         for i=1:nf;
             dataBF(:,i)=dataB(:,featureindex(i));
         end



    %%%%%%%%%
    node=cell(1,5);
    node{1,1}=dataBF;
    node{1,5}=resultsB;
    node{1,4}=1;

    path=cell(1,1);
    path{1}=node;


   
    treeEnd=0;
    while treeEnd==0
    iter=1;
    newpath=cell(0,0);
    h=length(path);
    notnew=0;
        for pathnum=1:h
            node=path{pathnum};
            nodenum=length(path{pathnum}(:,1));
            currentnodedata=path{pathnum}{nodenum,1};
            currentlabels=path{pathnum}{nodenum,5};
            
            %%%Done splitting??
            for q=1:10
            testa=sum(currentlabels==q)/length(currentlabels);
                if testa>.9
                    break
                end
            end
            
            if nodenum==nf || length(currentnodedata(:,1))<=10 || testa>.9 
                newpath{iter}=node;
                iter=iter+1;
                notnew=notnew+1;
                if notnew==h
                    treeEnd=1;
                    break
                end
                continue
            end
            
                [bestfeat,bestval,nodeL,Llabels,nodeR,Rlabels]=multiattAsplit(currentnodedata,currentlabels,featureindex);
                
                %%%% Save teh split and feature
                node{nodenum,2}=bestfeat;
                node{nodenum,3}=bestval;


                %%%%%%Create 2 new paths

                node(nodenum+1,:)=cell(1,5);
                node{nodenum+1,1}=nodeL;
                node{nodenum+1,4}=1;
                node{nodenum+1,5}=Llabels;
                newpath{iter}=node;
                iter=iter+1;
                
                node(nodenum+1,:)=cell(1,5);
                node{nodenum+1,1}=nodeR;
                node{nodenum+1,4}=0;
                node{nodenum+1,5}=Rlabels;
                newpath{iter}=node;
                iter=iter+1;
        end
    path=newpath;
    end    
    trees{j}=path;              %%%%%% Contains the whole forest
end

%% Calc Error & Predicted Classes

err=[];
treenums=[];
for i=1:100
[err(i),classes]=multirandomforesttest(testdata,testresults,trees,i);
treenums(i)=i;
i
end
%csvwrite_with_headers('SDSP_Tree_Error.txt',dataout,headers);




%% Create Confusion Matrix

[confusionmat,Pr,Re,F,Err]=makeconfusion2(classes, testresults);

outy=toc;
%% Derive Performance Measures 


%%%% //TODO



%% END