function err=errortest(data,results,trees)
%%Tree Run

[a,b]=size(data);

for x=1:a;
    call=0;
    for i=1:length(trees)%%%amount of trees
        
        for j=1:length(trees{i})%%amount of paths
            
            for k=1:length(trees{i}{j}(:,1))%%amount nodes
                if k==1
                
                    splitatt=trees{i}{j}{k,2};
                    splitval=trees{i}{j}{k,3};
                    
                    if data(x,splitatt)>=splitval
                       branch=1;
                    else
                       branch=0;
                    end
                
                elseif trees{i}{j}{k,4}==branch && k==length(trees{i}{j}(:,1))
                        classpoints=trees{i}{j}{3,5};
                        if sum(classpoints)>=0
                            call=call+1;
                        else
                            call=call-1;
                        end
                
                elseif trees{i}{j}{k,4}==branch
                    
                    splitatt=trees{i}{j}{k,2};
                    splitval=trees{i}{j}{k,3};
                    
                    if data(x,splitatt)>=splitval
                       branch=1;
                    else
                       branch=0;
                    end
                else
                    continue
                end
                
            end
        end
     end
        classes(x)=call;
end
sum(classes'<0);
classes=(classes>0)-(classes<=0);
right=(classes'==results);
err=sum(right)/length(results)*100;

