function [bestatt,bestval,Ldata,Llabels,Rdata,Rlabels]=multiattAsplit(data,labels,origindex)

len=length(data(1,:));
lenv=length(data(:,2));
for i=1:len
    newvals(i)=mean(data(:,i));
    Ldata=[];
    Rdata=[];
    indexL=[];
    indexR=[];
    for k=1:lenv
        if data(k,i)>=newvals(i)
            Ldata=[Ldata;data(k,:)];
            indexL=[indexL,k];
            %orgL=[orgL,origindex(i)];
        else
            Rdata=[Rdata;data(k,:)];
            indexR=[indexR,k];
            %orgR=[orgR,origindex(i)];
        end
    end
    Llabels=labels(indexL);
    Rlabels=labels(indexR);
    
    entropyres=multitakeent(labels);
    pL= length(Ldata)/lenv;
    pR= length(Rdata)/lenv;
    Lres=multitakeent(Llabels);
    Rres=multitakeent(Rlabels);
    entropys=pL*Lres+pR*Rres;
    newgains(i)=entropyres-entropys;
end
[~, ba]=max(newgains);
bestval=newvals(ba);
bestatt=origindex(ba);

    Ldata=[];
    Rdata=[];
    indexL=[];
    indexR=[];
 for k=1:lenv
        if data(k,ba)>=bestval
            Ldata=[Ldata;data(k,:)];
            indexL=[indexL,k];
            %orgL=[orgL,origindex(i)];
        else
            Rdata=[Rdata;data(k,:)];
            indexR=[indexR,k];
            %orgR=[orgR,origindex(i)];
        end
    end
    Llabels=labels(indexL);
    Rlabels=labels(indexR);



